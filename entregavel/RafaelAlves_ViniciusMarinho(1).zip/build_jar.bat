@echo off
echo Compilando fontes Java...
javac -cp src -d bin src/error/*.java src/lexer/*.java src/semantic/*.java src/codegen/*.java src/parser/*.java src/main/*.java
if errorlevel 1 (
    echo ERRO: falha na compilacao Java.
    exit /b 1
)

echo Empacotando BRL.jar...
where jar >nul 2>nul
if not errorlevel 1 (
    jar cfm BRL.jar MANIFEST.MF -C bin .
    if errorlevel 1 (
        echo ERRO: falha ao criar BRL.jar.
        exit /b 1
    )
) else (
    echo AVISO: jar.exe nao encontrado no PATH. Usando empacotamento ZIP via PowerShell...
    if exist BRL.jar del BRL.jar
    powershell -NoProfile -Command "$ErrorActionPreference='Stop'; Add-Type -AssemblyName System.IO.Compression; Add-Type -AssemblyName System.IO.Compression.FileSystem; $zip=[System.IO.Compression.ZipFile]::Open('BRL.jar',[System.IO.Compression.ZipArchiveMode]::Create); try { [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,(Resolve-Path 'MANIFEST.MF'),'META-INF/MANIFEST.MF') > $null; $bin=(Resolve-Path 'bin').Path; Get-ChildItem 'bin' -Recurse -File | ForEach-Object { $entry=$_.FullName.Substring($bin.Length+1).Replace('\','/'); [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$_.FullName,$entry) > $null } } finally { $zip.Dispose() }"
    if errorlevel 1 (
        echo ERRO: falha ao criar BRL.jar via PowerShell.
        exit /b 1
    )
)

echo Pronto: BRL.jar gerado com sucesso.
echo Uso: java -jar BRL.jar ^<fonte.LC^> ^<saida.ASM^>
echo      BRL.bat ^<fonte.LC^> ^<saida.ASM^>
